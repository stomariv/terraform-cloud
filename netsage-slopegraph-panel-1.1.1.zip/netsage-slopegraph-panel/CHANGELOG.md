# Changelog

## 1.1.0

- Update tooling to webpack
- Fix tooltips for Grafana 9.4+
- Add Label size/spacing options